import random
from spn import *

#generate plaintext
plaintexts = [random.getrandbits(16) for _ in range(10000)]

#save the plaintext in txt file
with open("plaintexts.txt", "w") as file:
    for pt in plaintexts:

        file.write(f"{hex(pt)}\n")

#round keys
keys = [0x30cf, 0x87e3, 0xdcff, 0xcd6, 0x43c7]

#encrypt the plaintext
ciphertexts = [spn(pt, keys) for pt in plaintexts]

#save the cipherext in txt file
with open("ciphertexts.txt", "w") as file:
    for ct in ciphertexts:

        file.write(f"{ct}\n")